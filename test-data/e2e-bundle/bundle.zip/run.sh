#!/bin/bash
# E2E test bundle: echo input params as CSV output row.
# Arguments: --param1 VALUE1 --param2 VALUE2 ... --output_path PATH
OUTPUT_PATH=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --output_path)
      OUTPUT_PATH="$2"
      shift 2
      ;;
    --*)
      shift 2
      ;;
    *)
      shift
      ;;
  esac
done

# Echo header + single row with sample_id=0
echo "sample_id,result" > "$OUTPUT_PATH"
echo "0,0" >> "$OUTPUT_PATH"
