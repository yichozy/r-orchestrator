#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CSV_FILE="${1:-"${SCRIPT_DIR}/params.csv"}"
ROW_NUM="${2:-1}"
OUTPUT_PATH="${3:-"pfs_simulation_results/design_report_wide_2.csv"}"

usage() {
  echo "Usage:"
  echo "  $0 --control_name \"mFOLFOX\" --event_size \"102\" ... --output_path \"out.csv\""
  echo "Usage: $0 [csv_file] [row_number] [output_path]"
  echo ""
  echo "  csv_file     Path to params.csv (default: ./params.csv)"
  echo "  row_number   1-based row number to run (default: 1)"
  echo "  output_path  Output file path for results (default: pfs_simulation_results/design_report_wide_2.csv)"
  echo ""
  echo "Examples:"
  echo "  $0                              # run row 1 of params.csv"
  echo "  $0 params.csv 5                 # run row 5"
  echo "  $0 params.csv 5 results/out.csv # run row 5 with custom output"
  exit 1
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
fi

if [[ "${1:-}" == --* ]]; then
  MAIN_R="${SCRIPT_DIR}/main.R"
  if [[ ! -f "$MAIN_R" ]]; then
    echo "Error: main.R not found at $MAIN_R"
    exit 1
  fi

  cd "$SCRIPT_DIR"
  exec Rscript "$MAIN_R" "$@"
fi

if [[ ! -f "$CSV_FILE" ]]; then
  echo "Error: CSV file not found: $CSV_FILE"
  exit 1
fi

# Read header
HEADER=()
IFS=',' read -ra HEADER < <(head -1 "$CSV_FILE")

# Build line count
TOTAL_LINES=$(tail -n +2 "$CSV_FILE" | wc -l | tr -d ' ')

if [[ "$ROW_NUM" -lt 1 || "$ROW_NUM" -gt "$TOTAL_LINES" ]]; then
  echo "Error: row_number $ROW_NUM out of range (1-$TOTAL_LINES)"
  exit 1
fi

# Read the target row
ROW_VALUES=()
IFS=',' read -ra ROW_VALUES < <(sed -n "$((ROW_NUM + 1))p" "$CSV_FILE")

# Build command arguments
CMD_ARGS=()
for i in "${!HEADER[@]}"; do
  PARAM="--${HEADER[$i]}"
  VALUE="${ROW_VALUES[$i]}"
  CMD_ARGS+=("$PARAM" "$VALUE")
done

# Add output path
CMD_ARGS+=("--output_path" "$OUTPUT_PATH")

MAIN_R="${SCRIPT_DIR}/main.R"
if [[ ! -f "$MAIN_R" ]]; then
  echo "Error: main.R not found at $MAIN_R"
  exit 1
fi

echo ">>> Running row $ROW_NUM / $TOTAL_LINES from $CSV_FILE"
echo ">>> Output: $OUTPUT_PATH"
echo ">>> Command: Rscript $MAIN_R ${CMD_ARGS[*]}"
echo ""

cd "$SCRIPT_DIR"
Rscript "$MAIN_R" "${CMD_ARGS[@]}"
