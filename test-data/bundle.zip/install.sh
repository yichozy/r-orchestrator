#!/usr/bin/env bash
set -euo pipefail

# ---------- Install R packages ----------
R_PACKAGES=(optparse foreach doParallel survival rpact)

echo ">>> Installing R packages: ${R_PACKAGES[*]}"
Rscript -e "
pkgs <- c('optparse','foreach','doParallel','survival','rpact')
for (pkg in pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    message(sprintf('Installing %s ...', pkg))
    install.packages(pkg, repos = 'https://cloud.r-project.org', quiet = TRUE)
  } else {
    message(sprintf('%s is already installed.', pkg))
  }
}
message('All packages ready.')
"

echo ">>> Installation complete."
