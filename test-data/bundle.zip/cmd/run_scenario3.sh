#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-"${SCRIPT_DIR}/output"}"
mkdir -p "$OUTPUT_DIR"

cd "$SCRIPT_DIR"
Rscript main.R \
  --event_size "117" \
  --event_size_cap "146" \
  --sample_size "150" \
  --sample_size_cap "188" \
  --time_to_event_control "3.74" \
  --time_to_event_treatment "5.5" \
  --dropout_rate_control "0.11" \
  --dropout_rate_treatment "0.07" \
  --dropout_rate_time "6" \
  --accrual_rate "8" \
  --alpha "0.10" \
  --sided "one-sided" \
  --interim_ratio "0.5" \
  --alpha_spending "asOF" \
  --beta_spending "bsOF" \
  --SSR "yes" \
  --CP_min 0.4 \
  --CP_max 0.8 \
  --target_CP 0.8 \
  --n_rep 2 \
  --seed 789 \
  --endpoint_name "Progression-Free Survival" \
  --treatment_name "FF-10832" \
  --control_name "mFOLFOX" \
  --output_path "${OUTPUT_DIR}/design_report_wide_run_scenario3.sh.csv"

echo ">>> run_scenario3.sh complete: ${OUTPUT_DIR}/design_report_wide_run_scenario3.sh.csv"
