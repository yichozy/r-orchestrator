#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-"${SCRIPT_DIR}/output"}"
mkdir -p "$OUTPUT_DIR"

cd "$SCRIPT_DIR"
Rscript main.R \
  --event_size "102" \
  --event_size_cap "128" \
  --sample_size "140" \
  --sample_size_cap "175" \
  --time_to_event_control "3.59" \
  --time_to_event_treatment "5.5" \
  --dropout_rate_control "0.11" \
  --dropout_rate_treatment "0.07" \
  --dropout_rate_time "6" \
  --accrual_rate "4" \
  --alpha "0.10" \
  --sided "one-sided" \
  --interim_ratio "0.5" \
  --alpha_spending "asOF" \
  --beta_spending "bsOF" \
  --SSR "yes" \
  --CP_min 0.4 \
  --CP_max 0.8 \
  --target_CP 0.8 \
  --n_rep 2 \
  --seed 123 \
  --endpoint_name "Progression-Free Survival" \
  --treatment_name "FF-10832" \
  --control_name "mFOLFOX" \
  --output_path "${OUTPUT_DIR}/design_report_wide_run_scenario1.sh.csv"

echo ">>> run_scenario1.sh complete: ${OUTPUT_DIR}/design_report_wide_run_scenario1.sh.csv"
