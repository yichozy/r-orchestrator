#!/usr/bin/env Rscript
if (!requireNamespace("foreach", quietly = TRUE)) {
  install.packages("foreach", repos = "https://cloud.r-project.org")
}
if (!requireNamespace("doParallel", quietly = TRUE)) {
  install.packages("doParallel", repos = "https://cloud.r-project.org")
}

library(foreach)
library(doParallel)

run_mc_event_driven_tte <- function(n_rep = 20000,
                                    seed = NULL,
                                    show_progress = TRUE,
                                    n_cores = max(1L, parallel::detectCores() - 1L),
                                    n_chunks = NULL,
                                    ...) {
  if (!requireNamespace("doParallel", quietly = TRUE)) stop("Package 'doParallel' is required.")
  if (!requireNamespace("foreach", quietly = TRUE)) stop("Package 'foreach' is required.")

  if (!is.numeric(n_rep) || length(n_rep) != 1 || is.na(n_rep) || n_rep <= 0) {
    stop("n_rep must be a single positive integer.")
  }
  n_rep <- as.integer(n_rep)

  if (!is.numeric(n_cores) || length(n_cores) != 1 || is.na(n_cores) || n_cores <= 0) {
    stop("n_cores must be a single positive integer.")
  }
  n_cores <- as.integer(n_cores)

  if (is.null(n_chunks)) n_chunks <- max(n_cores * 4L, 1L)
  if (!is.numeric(n_chunks) || length(n_chunks) != 1 || is.na(n_chunks) || n_chunks <= 0) {
    stop("n_chunks must be a single positive integer.")
  }
  n_chunks <- as.integer(min(n_chunks, n_rep))

  format_seconds <- function(sec) {
    sec <- max(0, round(sec))
    h <- sec %/% 3600
    m <- (sec %% 3600) %/% 60
    s <- sec %% 60
    sprintf("%02d:%02d:%02d", h, m, s)
  }

  # --------------------------------------------------------------------------
  # Validate required simulator helpers exist (fail fast; avoids silent worker failures)
  # --------------------------------------------------------------------------
  helper_fns <- c(
    "simulate_event_driven_tte",
    "rate_from_target",
    "randomize_two_arm",
    "generate_accrual_times",
    "compute_logrank_statistic",
    "get_critical_value",
    "get_interim_critical_value",
    "build_dataset_at_cutoff",
    "get_final_cp_bound",
    "cond_power",
    "inflate_event_size"
  )

  missing <- helper_fns[!vapply(helper_fns, exists, logical(1), envir = .GlobalEnv, inherits = TRUE)]
  if (length(missing) > 0) {
    stop(sprintf("Missing required functions in .GlobalEnv: %s", paste(missing, collapse = ", ")))
  }

  # --------------------------------------------------------------------------
  # Parallel setup
  # --------------------------------------------------------------------------
  cl <- parallel::makeCluster(n_cores)
  on.exit(parallel::stopCluster(cl), add = TRUE)

  doParallel::registerDoParallel(cl)

  if (!is.null(seed)) {
    parallel::clusterSetRNGStream(cl, iseed = seed)
  }

  parallel::clusterExport(cl, varlist = helper_fns, envir = .GlobalEnv)

  # --------------------------------------------------------------------------
  # Split reps into chunks for progress reporting
  # --------------------------------------------------------------------------
  rep_ids <- seq_len(n_rep)
  chunk_id <- cut(rep_ids, breaks = n_chunks, labels = FALSE)
  rep_chunks <- split(rep_ids, chunk_id)

  start_time <- Sys.time()
  chunk_results <- vector("list", length(rep_chunks))

  for (k in seq_along(rep_chunks)) {
    this_chunk <- rep_chunks[[k]]

    chunk_results[[k]] <- foreach::foreach(
      i = this_chunk,
      .combine = rbind,
      .packages = c("survival", "rpact"),
      .errorhandling = "stop"
    ) %dopar% {
      # Capture all arguments except return_patient_data; per-rep seed handled by cluster RNG stream
      args <- list(...)
      args$seed <- NULL
      args$return_patient_data <- FALSE

      res <- do.call(simulate_event_driven_tte, args)

      # Pull test-stat components (may be NULL/NA depending on edge cases)
      U <- if (!is.null(res$test_stat$U)) res$test_stat$U else NA_real_
      V <- if (!is.null(res$test_stat$V)) res$test_stat$V else NA_real_
      Z <- if (!is.null(res$test_stat$Z)) res$test_stat$Z else NA_real_

      # Extract HR estimates from simulation result (if available), otherwise calculate
      beta_hat <- if (!is.null(res$beta_hat)) res$beta_hat else
                   if (is.finite(U) && is.finite(V) && V > 0) U / V else NA_real_
      hr_hat <- if (!is.null(res$hr_hat)) res$hr_hat else
                if (is.finite(beta_hat)) exp(beta_hat) else NA_real_

      # "Insufficient information" derived purely from stats availability/validity
      insufficient_info <- !(is.finite(Z) && is.finite(V) && V > 0)

      data.frame(
        rep = i,
        zone_label = as.character(res$zone_label),
        reject = isTRUE(res$reject),
        early_stop = isTRUE(res$early_stop),
        ssr_triggered = isTRUE(res$ssr_triggered),
        cp = if (!is.null(res$cp)) res$cp else NA_real_,
        event_size_final = res$event_size_final,
        sample_size_final = res$sample_size_final,
        accrual_stop_time = res$timing$accrual_stop_time,
        analysis_time = res$timing$analysis_time,
        actual_sample_size = res$timing$actual_sample_size,
        observed_events = res$timing$observed_events,
        last_patient_followup = res$timing$last_patient_followup,
        n_dropout = res$timing$n_dropout,
        U = U,
        V = V,
        Z = Z,
        chisq = if (!is.null(res$test_stat$chisq)) res$test_stat$chisq else NA_real_,
        critical_value = res$critical_value,

        # Added fields for your wide report
        beta_hat = beta_hat,
        hr_hat = hr_hat,
        insufficient_info = insufficient_info,
        efficacy_bound = if (!is.null(res$interim_bounds))
          paste(round(res$interim_bounds$efficacy_bound, 4),
                collapse = ", ") else NA_character_,
        futility_bound = if (!is.null(res$interim_bounds) &&
            !all(is.na(res$interim_bounds$futility_bound)))
          paste(round(res$interim_bounds$futility_bound, 4),
                collapse = ", ") else NA_character_,

        stringsAsFactors = FALSE
      )
    }

    if (show_progress) {
      done <- sum(lengths(rep_chunks[seq_len(k)]))
      now_time <- Sys.time()
      elapsed <- as.numeric(difftime(now_time, start_time, units = "secs"))
      rate <- done / max(elapsed, 1e-9)
      remaining <- if (rate > 0) (n_rep - done) / rate else NA_real_
      eta_time <- now_time + remaining
      pct <- 100 * done / n_rep

      cat(sprintf(
        "\r[chunk %3d/%3d] reps %6d/%6d | %6.2f%% | elapsed: %s | remaining: %s | ETA: %s",
        k, length(rep_chunks), done, n_rep, pct,
        format_seconds(elapsed),
        if (is.na(remaining)) "NA" else format_seconds(remaining),
        format(eta_time, "%H:%M:%S")
      ))
      if (k == length(rep_chunks)) cat("\n")
      flush.console()
    }
  }

  raw_results <- do.call(rbind, chunk_results)
  raw_results <- raw_results[order(raw_results$rep), , drop = FALSE]
  rownames(raw_results) <- NULL

  zone_tab <- table(raw_results$zone_label)
  zone_prob <- prop.table(zone_tab)
  zone_prob_df <- data.frame(
    zone_label = names(zone_prob),
    probability = as.numeric(zone_prob),
    count = as.integer(zone_tab[names(zone_prob)]),
    row.names = NULL,
    stringsAsFactors = FALSE
  )

  power <- mean(raw_results$reject)
  mc_se_power <- sqrt(power * (1 - power) / n_rep)

  end_time <- Sys.time()
  total_elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))

  summary_list <- list(
    n_rep = n_rep,
    n_cores = n_cores,
    n_chunks = length(rep_chunks),
    power = power,
    mc_se_power = mc_se_power,
    total_elapsed_seconds = total_elapsed,
    total_elapsed_hms = format_seconds(total_elapsed),
    zone_probability = zone_prob_df,
    early_stop_probability = mean(raw_results$early_stop),
    ssr_trigger_probability = mean(raw_results$ssr_triggered),
    mean_cp = mean(raw_results$cp, na.rm = TRUE),
    mean_event_size_final = mean(raw_results$event_size_final),
    mean_sample_size_final = mean(raw_results$sample_size_final),
    mean_actual_sample_size = mean(raw_results$actual_sample_size),
    mean_analysis_time = mean(raw_results$analysis_time),
    mean_last_patient_followup = mean(raw_results$last_patient_followup),
    mean_dropout = mean(raw_results$n_dropout),

    # Added: counts from derived insufficient_info
    n_insufficient_info = sum(raw_results$insufficient_info, na.rm = TRUE),
    p_insufficient_info = mean(raw_results$insufficient_info, na.rm = TRUE),

    # Added: mean/median HR estimate (useful sanity checks)
    mean_hr_hat = mean(raw_results$hr_hat, na.rm = TRUE),
    median_hr_hat = stats::median(raw_results$hr_hat, na.rm = TRUE),
    efficacy_bound = raw_results$efficacy_bound[1],
    futility_bound = raw_results$futility_bound[1]
  )

  list(
    summary = summary_list,
    raw_results = raw_results
  )
}