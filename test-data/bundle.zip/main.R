#!/usr/bin/env Rscript

suppressWarnings(suppressPackageStartupMessages({
  if (!requireNamespace("optparse", quietly = TRUE)) {
    install.packages("optparse", repos = "https://cloud.r-project.org")
  }
  if (!requireNamespace("foreach", quietly = TRUE)) {
    install.packages("foreach", repos = "https://cloud.r-project.org")
  }
  if (!requireNamespace("doParallel", quietly = TRUE)) {
    install.packages("doParallel", repos = "https://cloud.r-project.org")
  }
  if (!requireNamespace("survival", quietly = TRUE)) {
    install.packages("survival", repos = "https://cloud.r-project.org")
  }
  if (!requireNamespace("rpact", quietly = TRUE)) {
    install.packages("rpact", repos = "https://cloud.r-project.org")
  }

  library(optparse)
  library(foreach)
  library(doParallel)
  library(survival)
  library(rpact)
}))

# ------------------------------------------------------------------------------
# Small utilities
# ------------------------------------------------------------------------------
trim_ws <- function(x) gsub("^\\s+|\\s+$", "", x)

safe_dir_create <- function(path) {
  if (!dir.exists(path)) dir.create(path, recursive = TRUE, showWarnings = FALSE)
}

resolve_ncore <- function(ncore) {
  detected <- parallel::detectCores(logical = TRUE)
  if (is.na(detected) || detected < 1) detected <- 1L
  ncore <- as.integer(ncore)
  if (is.na(ncore) || ncore < 1) ncore <- 1L
  min(ncore, detected)
}

fmt_seconds <- function(sec) {
  sec <- max(0, round(sec))
  h <- sec %/% 3600
  m <- (sec %% 3600) %/% 60
  s <- sec %% 60
  sprintf("%02d:%02d:%02d", h, m, s)
}

# Percentile helper (safe for all-NA / empty)
q_safe <- function(x, probs) {
  x <- x[is.finite(x)]
  if (length(x) == 0) return(rep(NA_real_, length(probs)))
  as.numeric(stats::quantile(x, probs = probs, names = FALSE, type = 7))
}

# Safe distribution summary (min/max/5/25/50/75/95/sd)
summ_vec <- function(x) {
  x <- x[is.finite(x)]
  if (length(x) == 0) {
    return(list(min=NA_real_, max=NA_real_, q05=NA_real_, q25=NA_real_, q50=NA_real_, q75=NA_real_, q95=NA_real_, sd=NA_real_))
  }
  qs <- as.numeric(stats::quantile(x, probs = c(0.05, 0.25, 0.50, 0.75, 0.95), names = FALSE, type = 7))
  list(
    min = min(x), max = max(x),
    q05 = qs[1], q25 = qs[2], q50 = qs[3], q75 = qs[4], q95 = qs[5],
    sd  = stats::sd(x)
  )
}

zone_mean <- function(raw, var, z) {
  idx <- which(raw$zone_label == z)
  if (length(idx) == 0) return(NA_real_)
  mean(raw[[var]][idx], na.rm = TRUE)
}

# ------------------------------------------------------------------------------
# Batch parsing helpers
# ------------------------------------------------------------------------------
parse_numvec <- function(x) {
  if (is.null(x) || is.na(x) || trim_ws(x) == "") return(numeric(0))
  x <- trim_ws(x)
  if (grepl("^seq\\(", x)) {
    inside <- sub("^seq\\((.*)\\)$", "\\1", x)
    parts <- strsplit(inside, ",")[[1]]
    parts <- as.numeric(trim_ws(parts))
    if (length(parts) == 3) return(seq(parts[1], parts[2], by = parts[3]))
    if (length(parts) == 2) return(seq(parts[1], parts[2]))
    stop("seq() must be seq(from,to,by) or seq(from,to)")
  }
  vals <- as.numeric(trim_ws(strsplit(x, ",")[[1]]))
  if (any(is.na(vals))) stop(sprintf("Could not parse numeric vector: %s", x))
  vals
}

parse_charvec <- function(x) {
  if (is.null(x) || is.na(x) || trim_ws(x) == "") return(character(0))
  trim_ws(strsplit(x, ",")[[1]])
}

vec_or_single <- function(v, fallback_scalar) {
  if (length(v) == 0) return(as.character(fallback_scalar))
  v
}

stop_if_missing_vec <- function(v, name) {
  if (length(v) == 0) stop(sprintf("Missing required option: %s", name))
}

# ------------------------------------------------------------------------------
# CLI options
# ------------------------------------------------------------------------------
option_list <- list(
  # MC controls (scalar)
  make_option("--n_rep", type = "integer", default = 20000,
              help = "Monte Carlo replicates per model. [default %default]"),
  make_option("--ncore", type = "integer", default = 1,
              help = "Number of CPU cores (doParallel). [default %default]"),
  make_option("--seed", type = "integer", default = 123,
              help = "Base seed; ModelID is added for model-specific seeds. [default %default]"),
  make_option("--show_progress", type = "character", default = "yes",
              help = "yes/no progress printing. [default %default]"),
  make_option("--save_raw", type = "character", default = "yes",
              help = "yes/no to write raw_results.csv (per model). [default %default]"),

  # Design inputs (batchable)
  make_option("--event_size", type = "character", default = NA,
              help = "Planned number of events. e.g. '98' or '98,120' or 'seq(80,120,10)'."),
  make_option("--sample_size", type = "character", default = NA,
              help = "Planned max sample size. e.g. '200' or '180,200,220' or 'seq(160,260,20)'."),
  make_option("--time_to_event_control", type = "character", default = NA,
              help = "Control median TTE. e.g. '4.0' or '3.5,4.0,4.5'."),
  make_option("--time_to_event_treatment", type = "character", default = NA,
              help = "Treatment median TTE. e.g. '6.0' or '5.5,6.0'."),
  make_option("--dropout_rate_control", type = "character", default = NA,
              help = "Cumulative dropout prob in control by dropout_rate_time. e.g. '0.05' or '0.02,0.05'."),
  make_option("--dropout_rate_treatment", type = "character", default = NA,
              help = "Cumulative dropout prob in treatment by dropout_rate_time. e.g. '0.05' or '0.02,0.05'."),
  make_option("--dropout_rate_time", type = "character", default = NA,
              help = "Time horizon for dropout probabilities. e.g. '12' or '12,18'."),
  make_option("--accrual_rate", type = "character", default = NA,
              help = "Accrual rate (patients/month). e.g. '10' or '8,10,12'."),

  make_option("--alpha", type = "character", default = "0.10",
              help = "Type I error alpha. e.g. '0.1' or '0.05,0.1'. [default %default]"),
  make_option("--sided", type = "character", default = "one-sided",
              help = "one-sided or two-sided; can be vector: 'one-sided,two-sided'. [default %default]"),
  make_option("--allocation_ratio", type = "character", default = "1",
              help = "Treatment:Control allocation ratio; can be vector: '1,2'. [default %default]"),
  make_option("--accrual_model", type = "character", default = "poisson",
              help = "poisson or fixed_spacing. [default %default]"),
  make_option("--randomization_method", type = "character", default = "blocked",
              help = "blocked or bernoulli. [default %default]"),
  make_option("--block_size", type = "integer", default = 6,
              help = "Block size (used if randomization_method=blocked). [default %default]"),

  # Interim / spending (batchable)
  make_option("--interim_ratio", type = "character", default = NA,
              help = "Interim information fraction(s). e.g. '0.5' or '0.4,0.5'. If NA/blank => no interim."),
  make_option("--efficacy_stop", type = "character", default = "yes",
              help = "yes/no efficacy stopping at interim. [default %default]"),
  make_option("--futility_stop", type = "character", default = "yes",
              help = "yes/no futility stopping at interim. [default %default]"),
  make_option("--alpha_spending", type = "character", default = "asOF",
              help = "rpact alpha spending typeOfDesign; can be vector: 'asOF,asP'. [default %default]"),
  make_option("--beta_spending", type = "character", default = "bsOF",
              help = "rpact beta spending typeBetaSpending; can be vector: 'bsOF,bsP'. [default %default]"),
  make_option("--beta", type = "double", default = 0.20,
              help = "Beta for GSD futility spending (1-power). [default %default]"),

  # SSR inputs
  make_option("--SSR", type = "character", default = "no",
              help = "yes/no SSR at interim (promising zone). [default %default]"),
  make_option("--CP_min", type = "double", default = 0.4,
              help = "Promising zone CP min. [default %default]"),
  make_option("--CP_max", type = "double", default = 0.8,
              help = "Promising zone CP max. [default %default]"),
  make_option("--target_CP", type = "double", default = 0.8,
              help = "Target CP inside promising zone. [default %default]"),
  make_option("--event_size_cap", type = "character", default = NA,
              help = "Max events after SSR. e.g. '123' or '88,123'."),
  make_option("--sample_size_cap", type = "character", default = NA,
              help = "Max sample size after SSR. e.g. '175' or '150,175'."),

  # Metadata / output
  make_option("--endpoint_name", type = "character", default = "PFS",
              help = "EndpointName in output. [default %default]"),
  make_option("--treatment_name", type = "character", default = "Experimental",
              help = "TreatmentName in output. [default %default]"),
  make_option("--control_name", type = "character", default = "Control",
              help = "ControlName in output. [default %default]"),
  make_option("--time_unit", type = "character", default = "Month",
              help = "TimeUnit in output. [default %default]"),
  make_option("--output_path", type = "character", default = "tte_mc_results/design_report_wide.csv",
              help = "Output file path (directory will be created if needed). e.g. 'pfs_simulation_results/design_report_wide.csv'. [default %default]")
)

parser <- OptionParser(option_list = option_list, usage = "%prog [options]")
opt <- parse_args(parser)

# ------------------------------------------------------------------------------
# Parse batch inputs into vectors
# ------------------------------------------------------------------------------
event_size_vec   <- parse_numvec(opt$event_size)
sample_size_vec  <- parse_numvec(opt$sample_size)
tte_c_vec        <- parse_numvec(opt$time_to_event_control)
tte_t_vec        <- parse_numvec(opt$time_to_event_treatment)
drop_c_vec       <- parse_numvec(opt$dropout_rate_control)
drop_t_vec       <- parse_numvec(opt$dropout_rate_treatment)
drop_time_vec    <- parse_numvec(opt$dropout_rate_time)
accrual_vec      <- parse_numvec(opt$accrual_rate)
alpha_vec        <- parse_numvec(opt$alpha)
alloc_vec        <- parse_numvec(opt$allocation_ratio)
interim_vec      <- parse_numvec(opt$interim_ratio)
event_cap_vec    <- parse_numvec(opt$event_size_cap)
sample_cap_vec   <- parse_numvec(opt$sample_size_cap)

alpha_spend_vec  <- vec_or_single(parse_charvec(opt$alpha_spending), opt$alpha_spending)
beta_spend_vec   <- vec_or_single(parse_charvec(opt$beta_spending),  opt$beta_spending)
sided_vec        <- vec_or_single(parse_charvec(opt$sided),          opt$sided)

# ------------------------------------------------------------------------------
# Validate required inputs
# ------------------------------------------------------------------------------
stop_if_missing_vec(event_size_vec, "--event_size")
stop_if_missing_vec(sample_size_vec, "--sample_size")
stop_if_missing_vec(tte_c_vec, "--time_to_event_control")
stop_if_missing_vec(tte_t_vec, "--time_to_event_treatment")
stop_if_missing_vec(drop_c_vec, "--dropout_rate_control")
stop_if_missing_vec(drop_t_vec, "--dropout_rate_treatment")
stop_if_missing_vec(drop_time_vec, "--dropout_rate_time")
stop_if_missing_vec(accrual_vec, "--accrual_rate")

# If user didn't pass alpha/allocation_ratio explicitly, use defaults as singletons
if (length(alpha_vec) == 0) alpha_vec <- as.numeric(opt$alpha)
if (length(alloc_vec) == 0) alloc_vec <- as.numeric(opt$allocation_ratio)

use_progress <- tolower(trim_ws(opt$show_progress)) %in% c("yes", "true", "1")
save_raw     <- tolower(trim_ws(opt$save_raw)) %in% c("yes", "true", "1")
eff_stop     <- tolower(trim_ws(opt$efficacy_stop)) %in% c("yes", "true", "1")
fut_stop     <- tolower(trim_ws(opt$futility_stop)) %in% c("yes", "true", "1")
SSR_flag     <- tolower(trim_ws(opt$SSR)) %in% c("yes", "true", "1")

# Auto-determine design name based on parameters
has_interim_input <- length(interim_vec) > 0
if (SSR_flag && has_interim_input) {
  auto_design_name <- "Group Sequential Design with Sample Size Re-estimation"
} else if (!SSR_flag && has_interim_input) {
  auto_design_name <- "Group Sequential Design"
} else {
  auto_design_name <- "Fixed Sample Design"
}

# Force save_raw=TRUE for fixed design to calculate quantiles
if (!has_interim_input) {
  save_raw <- TRUE
}

# ------------------------------------------------------------------------------
# Load simulator functions based on SSR setting
# ------------------------------------------------------------------------------
if (SSR_flag) {
  source(file.path("Survival-SSR.R"))
  source(file.path("MC-Survival-SSR.R"))   # should define run_mc_event_driven_tte()
} else {
  source(file.path("Survival-GSD.R"))
  source(file.path("MC-Survival-GSD.R"))   # should define run_mc_event_driven_tte()
}

ncore <- resolve_ncore(opt$ncore)
output_file <- opt$output_path
output_dir  <- dirname(output_file)
safe_dir_create(output_dir)

# ------------------------------------------------------------------------------
# Build grid + ModelID
# Interim: if user didn't provide, include "no interim" only (NA)
# Event size/cap and sample size/cap pairing: handle single-single, vector-single, single-vector, vector-vector (same length)
# ------------------------------------------------------------------------------
interim_grid <- if (length(interim_vec) == 0) NA_real_ else interim_vec

# Handle event_size and event_size_cap pairing
# Cases:
# 1. Both single: event_size=100, cap=150 → 1 pair (100, 150)
# 2. Vector vs single: event_size=100,120, cap=150 → 2 pairs: (100,150), (120,150)
# 3. Single vs vector: event_size=100, cap=150,180 → 2 pairs: (100,150), (100,180)
# 4. Vector vs vector (same length): event_size=100,120, cap=150,180 → 2 pairs: (100,150), (120,180)
if (length(event_cap_vec) == 0) {
  event_pairs <- data.frame(
    event_size = event_size_vec,
    event_size_cap = NA_integer_,
    stringsAsFactors = FALSE
  )
} else if (length(event_cap_vec) == 1) {
  event_pairs <- data.frame(
    event_size = event_size_vec,
    event_size_cap = rep(event_cap_vec, length(event_size_vec)),
    stringsAsFactors = FALSE
  )
} else if (length(event_size_vec) == 1) {
  event_pairs <- data.frame(
    event_size = rep(event_size_vec, length(event_cap_vec)),
    event_size_cap = event_cap_vec,
    stringsAsFactors = FALSE
  )
} else if (length(event_size_vec) == length(event_cap_vec)) {
  event_pairs <- data.frame(
    event_size = event_size_vec,
    event_size_cap = event_cap_vec,
    stringsAsFactors = FALSE
  )
} else {
  stop("event_size and event_size_cap must have the same length when both are vectors")
}

# Handle sample_size and sample_size_cap pairing
# Cases:
# 1. Both single: sample_size=214, cap=321 → 1 pair (214, 321)
# 2. Vector vs single: sample_size=214,238, cap=321 → 2 pairs: (214,321), (238,321)
# 3. Single vs vector: sample_size=214, cap=321,357 → 2 pairs: (214,321), (214,357)
# 4. Vector vs vector (same length): sample_size=214,238, cap=321,357 → 2 pairs: (214,321), (238,357)
if (length(sample_cap_vec) == 0) {
  sample_pairs <- data.frame(
    sample_size = sample_size_vec,
    sample_size_cap = NA_integer_,
    stringsAsFactors = FALSE
  )
} else if (length(sample_cap_vec) == 1) {
  sample_pairs <- data.frame(
    sample_size = sample_size_vec,
    sample_size_cap = rep(sample_cap_vec, length(sample_size_vec)),
    stringsAsFactors = FALSE
  )
} else if (length(sample_size_vec) == 1) {
  sample_pairs <- data.frame(
    sample_size = rep(sample_size_vec, length(sample_cap_vec)),
    sample_size_cap = sample_cap_vec,
    stringsAsFactors = FALSE
  )
} else if (length(sample_size_vec) == length(sample_cap_vec)) {
  sample_pairs <- data.frame(
    sample_size = sample_size_vec,
    sample_size_cap = sample_cap_vec,
    stringsAsFactors = FALSE
  )
} else {
  stop("sample_size and sample_size_cap must have the same length when both are vectors")
}

other_grid <- expand.grid(
  time_to_event_control = tte_c_vec,
  time_to_event_treatment = tte_t_vec,
  dropout_rate_control = drop_c_vec,
  dropout_rate_treatment = drop_t_vec,
  dropout_rate_time = drop_time_vec,
  accrual_rate = accrual_vec,
  alpha = alpha_vec,
  allocation_ratio = alloc_vec,
  interim_ratio = interim_grid,
  alpha_spending = alpha_spend_vec,
  beta_spending = beta_spend_vec,
  sided = sided_vec,
  stringsAsFactors = FALSE
)

grid <- expand.grid(
  event_pair_idx = seq_len(nrow(event_pairs)),
  sample_pair_idx = seq_len(nrow(sample_pairs)),
  other_idx = seq_len(nrow(other_grid)),
  stringsAsFactors = FALSE
)

grid$event_size <- event_pairs$event_size[grid$event_pair_idx]
grid$event_size_cap <- event_pairs$event_size_cap[grid$event_pair_idx]
grid$sample_size <- sample_pairs$sample_size[grid$sample_pair_idx]
grid$sample_size_cap <- sample_pairs$sample_size_cap[grid$sample_pair_idx]
grid$time_to_event_control <- other_grid$time_to_event_control[grid$other_idx]
grid$time_to_event_treatment <- other_grid$time_to_event_treatment[grid$other_idx]
grid$dropout_rate_control <- other_grid$dropout_rate_control[grid$other_idx]
grid$dropout_rate_treatment <- other_grid$dropout_rate_treatment[grid$other_idx]
grid$dropout_rate_time <- other_grid$dropout_rate_time[grid$other_idx]
grid$accrual_rate <- other_grid$accrual_rate[grid$other_idx]
grid$alpha <- other_grid$alpha[grid$other_idx]
grid$allocation_ratio <- other_grid$allocation_ratio[grid$other_idx]
grid$interim_ratio <- other_grid$interim_ratio[grid$other_idx]
grid$alpha_spending <- other_grid$alpha_spending[grid$other_idx]
grid$beta_spending <- other_grid$beta_spending[grid$other_idx]
grid$sided <- other_grid$sided[grid$other_idx]

grid$event_pair_idx <- NULL
grid$sample_pair_idx <- NULL
grid$other_idx <- NULL

grid$ModelID <- seq_len(nrow(grid))

# ------------------------------------------------------------------------------
# Run grid
# ------------------------------------------------------------------------------
cat("============================================================\n")
cat("Event-driven TTE Monte Carlo (GRID MODE)\n")
cat("============================================================\n")
cat(sprintf("Output file: %s\n", normalizePath(output_file, winslash = "/", mustWork = FALSE)))
cat(sprintf("n_rep per model: %d\n", as.integer(opt$n_rep)))
cat(sprintf("n_models: %d\n", nrow(grid)))
cat(sprintf("ncore: %d\n", ncore))
cat(sprintf("base seed: %s\n", as.character(opt$seed)))
cat(sprintf("efficacy_stop: %s\n", eff_stop))
cat(sprintf("futility_stop: %s\n", fut_stop))
cat(sprintf("SSR: %s\n", SSR_flag))
cat("============================================================\n")

design_rows <- vector("list", nrow(grid))
t0_all <- Sys.time()

for (i in seq_len(nrow(grid))) {
  g <- grid[i, ]

  model_seed <- as.integer(opt$seed) + as.integer(g$ModelID)

  interim_ratio <- if (is.finite(g$interim_ratio)) as.numeric(g$interim_ratio) else NULL

  cat(sprintf("\n--- ModelID %d / %d ---\n", g$ModelID, nrow(grid)))
  cat(sprintf("event=%d, n=%d, medC=%.4f, medT=%.4f, HR_input=%.6f, interim=%s, sided=%s, alpha=%.4f, alloc=%.3f\n",
              as.integer(g$event_size), as.integer(g$sample_size),
              as.numeric(g$time_to_event_control), as.numeric(g$time_to_event_treatment),
              as.numeric(g$time_to_event_control) / as.numeric(g$time_to_event_treatment),
              if (is.null(interim_ratio)) "None" else sprintf("%.4f", interim_ratio),
              as.character(g$sided),
              as.numeric(g$alpha),
              as.numeric(g$allocation_ratio)))

  t0 <- Sys.time()

  base_args <- list(
    n_rep = as.integer(opt$n_rep),
    seed = model_seed,
    show_progress = use_progress,
    n_cores = ncore,

    event_size = as.integer(g$event_size),
    sample_size = as.integer(g$sample_size),
    time_to_event_control = as.numeric(g$time_to_event_control),
    time_to_event_treatment = as.numeric(g$time_to_event_treatment),
    dropout_rate_control = as.numeric(g$dropout_rate_control),
    dropout_rate_treatment = as.numeric(g$dropout_rate_treatment),
    dropout_rate_time = as.numeric(g$dropout_rate_time),
    accrual_rate = as.numeric(g$accrual_rate),

    alpha = as.numeric(g$alpha),
    sided = as.character(g$sided),
    allocation_ratio = as.numeric(g$allocation_ratio),

    accrual_model = opt$accrual_model,
    randomization_method = opt$randomization_method,
    block_size = opt$block_size,

    interim_ratio = interim_ratio,
    efficacy_stop = eff_stop,
    futility_stop = fut_stop,
    alpha_spending = as.character(g$alpha_spending),
    beta_spending = as.character(g$beta_spending),
    beta = as.numeric(opt$beta),

    return_patient_data = FALSE
  )

  if (SSR_flag) {
    base_args$SSR <- TRUE
    base_args$CP_min <- as.numeric(opt$CP_min)
    base_args$CP_max <- as.numeric(opt$CP_max)
    base_args$target_CP <- as.numeric(opt$target_CP)
    base_args$event_size_cap <- if (is.na(g$event_size_cap)) NA_integer_ else as.integer(g$event_size_cap)
    base_args$sample_size_cap <- if (is.na(g$sample_size_cap)) NA_integer_ else as.integer(g$sample_size_cap)
  }

  mc <- do.call(run_mc_event_driven_tte, base_args)

  t1 <- Sys.time()
  elapsed <- as.numeric(difftime(t1, t0, units = "secs"))

  raw <- mc$raw_results
  summ <- mc$summary

  # SSR-only safety: derive hr_hat / insufficient_info if missing (older runner)
  if (SSR_flag) {
    if (!("hr_hat" %in% names(raw)) && all(c("U","V") %in% names(raw))) {
      raw$beta_hat <- with(raw, ifelse(is.finite(U) & is.finite(V) & V > 0, U / V, NA_real_))
      raw$hr_hat <- exp(raw$beta_hat)
    }
    if (!("insufficient_info" %in% names(raw))) {
      if (all(c("Z","V") %in% names(raw))) {
        raw$insufficient_info <- !(is.finite(raw$Z) & is.finite(raw$V) & raw$V > 0)
      } else {
        raw$insufficient_info <- rep(FALSE, nrow(raw))
      }
    }
  }

  # -----------------------------
  # Build one-row design report for this model
  # -----------------------------
  time_to_event_hr_input <- as.numeric(g$time_to_event_control) / as.numeric(g$time_to_event_treatment)

  n_interim <- if (is.null(interim_ratio)) 0L else 1L
  interim_spacing <- if (is.null(interim_ratio)) NA_real_ else interim_ratio * 100

  # For Survival endpoints, one-sided tests are always Left Tailed (reject when Z < 0, meaning HR < 1)
  tail_type <- if (tolower(as.character(g$sided)) == "one-sided") {
    "Left Tailed"  # Reject when Z is large negative (HR < 1, lower hazard is better)
  } else {
    "Two Tailed"
  }
  test_type <- if (tolower(as.character(g$sided)) == "one-sided") "1-sided" else "2-sided"

  probs <- c(0.05, 0.25, 0.50, 0.75, 0.95)

  ss   <- raw$actual_sample_size
  ev   <- raw$observed_events
  dr   <- raw$n_dropout
  fu   <- raw$last_patient_followup
  ac   <- raw$accrual_stop_time
  sdur <- raw$analysis_time

  ss_q <- q_safe(ss, probs)
  ev_q <- q_safe(ev, probs)
  dr_q <- q_safe(dr, probs)
  fu_q <- q_safe(fu, probs)
  ac_q <- q_safe(ac, probs)
  sd_q <- q_safe(sdur, probs)

  # HR estimate if available
  if ("hr_hat" %in% names(raw)) {
    hr_hat_vec <- raw$hr_hat
    hr_s <- summ_vec(hr_hat_vec)
  } else {
    hr_hat_vec <- NULL
    hr_s <- list(min=NA_real_, max=NA_real_, q05=NA_real_, q25=NA_real_, q50=NA_real_, q75=NA_real_, q95=NA_real_, sd=NA_real_)
  }

  # -----------------------------
  # Fixed design output (simplified)
  # -----------------------------
  if (!has_interim_input) {
    design_row <- data.frame(
      ModelID = as.integer(g$ModelID),

      StatisticalDesign = auto_design_name,
      TimeUnit = opt$time_unit,
      EndpointName = opt$endpoint_name,
      TreatmentName = opt$treatment_name,
      ControlName = opt$control_name,

      EndpointType = "Time to Event",
      TimetoEventModel = "Exponential",
      TimetoEventInputMethod = "Median Survival Time",
      TimetoEventControl = as.numeric(g$time_to_event_control),
      TimetoEventTreatment = as.numeric(g$time_to_event_treatment),
      TimetoEventHR = time_to_event_hr_input,

      DropoutModel = "Exponential",
      DropoutInputMethod = "Probability of Dropout",
      DropoutByTime = as.numeric(g$dropout_rate_time),
      DropoutControl = as.numeric(g$dropout_rate_control),
      DropoutTreatment = as.numeric(g$dropout_rate_treatment),

      EnrollmentInputMethod = "Enrollment Rate",
      EnrollmentDistribution = if (tolower(opt$accrual_model) == "poisson") "Exponential" else "Deterministic",

      DesignName = auto_design_name,
      Arms = 2,
      Hypothesis = "Superiority",

      NumberofEvents = as.integer(g$event_size),
      SampleSize = as.integer(g$sample_size),
      AllocationRatio = as.numeric(g$allocation_ratio),

      Type1Error = as.numeric(g$alpha),
      TestStatistic = "Logrank",
      TestType = test_type,
      TailType = tail_type,

      NumberOfSimulationRun = as.integer(opt$n_rep),
      FixedSeed = 1L,
      SeedValue = model_seed,

      AveragePower = summ$power,
      MCSEPower = summ$mc_se_power,

      AverageSampleSize = mean(ss, na.rm = TRUE),
      SampleSizeSD = stats::sd(ss, na.rm = TRUE),
      SampleSizeMin = min(ss, na.rm = TRUE),
      SampleSizeMax = max(ss, na.rm = TRUE),
      SampleSizeQ05 = ss_q[1],
      SampleSizeQ25 = ss_q[2],
      SampleSizeQ50 = ss_q[3],
      SampleSizeQ75 = ss_q[4],
      SampleSizeQ95 = ss_q[5],

      AverageNumberofEvents = mean(ev, na.rm = TRUE),
      NumberofEventsSD = stats::sd(ev, na.rm = TRUE),
      NumberofEventsMin = min(ev, na.rm = TRUE),
      NumberofEventsMax = max(ev, na.rm = TRUE),
      NumberofEventsQ05 = ev_q[1],
      NumberofEventsQ25 = ev_q[2],
      NumberofEventsQ50 = ev_q[3],
      NumberofEventsQ75 = ev_q[4],
      NumberofEventsQ95 = ev_q[5],

      AverageDropouts = mean(dr, na.rm = TRUE),
      DropoutsSD = stats::sd(dr, na.rm = TRUE),
      DropoutsMin = min(dr, na.rm = TRUE),
      DropoutsMax = max(dr, na.rm = TRUE),
      DropoutsQ05 = dr_q[1],
      DropoutsQ25 = dr_q[2],
      DropoutsQ50 = dr_q[3],
      DropoutsQ75 = dr_q[4],
      DropoutsQ95 = dr_q[5],

      AverageStudyDuration = mean(sdur, na.rm = TRUE),
      StudyDurationSD = stats::sd(sdur, na.rm = TRUE),
      StudyDurationMin = min(sdur, na.rm = TRUE),
      StudyDurationMax = max(sdur, na.rm = TRUE),
      StudyDurationQ05 = sd_q[1],
      StudyDurationQ25 = sd_q[2],
      StudyDurationQ50 = sd_q[3],
      StudyDurationQ75 = sd_q[4],
      StudyDurationQ95 = sd_q[5],

      AverageAccrualDuration = mean(ac, na.rm = TRUE),
      AccrualDurationSD = stats::sd(ac, na.rm = TRUE),
      AccrualDurationMin = min(ac, na.rm = TRUE),
      AccrualDurationMax = max(ac, na.rm = TRUE),
      AccrualDurationQ05 = ac_q[1],
      AccrualDurationQ25 = ac_q[2],
      AccrualDurationQ50 = ac_q[3],
      AccrualDurationQ75 = ac_q[4],
      AccrualDurationQ95 = ac_q[5],

      AverageFollowUpTime = mean(fu, na.rm = TRUE),
      FollowUpTimeSD = stats::sd(fu, na.rm = TRUE),
      FollowUpTimeMin = min(fu, na.rm = TRUE),
      FollowUpTimeMax = max(fu, na.rm = TRUE),
      FollowUpTimeQ05 = fu_q[1],
      FollowUpTimeQ25 = fu_q[2],
      FollowUpTimeQ50 = fu_q[3],
      FollowUpTimeQ75 = fu_q[4],
      FollowUpTimeQ95 = fu_q[5],

      stringsAsFactors = FALSE
    )

    # Add HR estimate statistics if available
    if (!is.null(hr_hat_vec)) {
      design_row$AverageObservedHR <- mean(hr_hat_vec, na.rm = TRUE)
      design_row$MedianObservedHR <- stats::median(hr_hat_vec, na.rm = TRUE)
      design_row$HRSD <- hr_s$sd
      design_row$HRMin <- hr_s$min
      design_row$HRMax <- hr_s$max
      design_row$HRQ05 <- hr_s$q05
      design_row$HRQ25 <- hr_s$q25
      design_row$HRQ50 <- hr_s$q50
      design_row$HRQ75 <- hr_s$q75
      design_row$HRQ95 <- hr_s$q95
    }

  } else {
    # -----------------------------
    # GSD/SSR design output (full)
    # -----------------------------
    zone_prob <- prop.table(table(raw$zone_label))
    p_unfav <- if ("unfavorable" %in% names(zone_prob)) as.numeric(zone_prob["unfavorable"]) else 0
    p_prom  <- if ("promising"   %in% names(zone_prob)) as.numeric(zone_prob["promising"]) else 0
    p_fav   <- if ("favorable"   %in% names(zone_prob)) as.numeric(zone_prob["favorable"]) else 0
    p_eff   <- if ("efficacy"    %in% names(zone_prob)) as.numeric(zone_prob["efficacy"]) else 0
    p_fut   <- if ("futility"    %in% names(zone_prob)) as.numeric(zone_prob["futility"]) else 0

    power_by_zone <- function(z) {
      idx <- which(raw$zone_label == z)
      if (length(idx) == 0) return(NA_real_)
      mean(raw$reject[idx], na.rm = TRUE)
    }

    # You can later replace these with real rpact boundaries if you want.
    eff_bound_1 <- NA
    fut_bound_1 <- NA

    design_row <- data.frame(
      ModelID = as.integer(g$ModelID),

      StatisticalDesign = auto_design_name,
      ScenarioKey = NA,
      DesignKey = NA,
      NumberofInterimAnalysis = n_interim,
      InterimAnalysisSpacing = interim_spacing,
      TimeUnit = opt$time_unit,
      EndpointName = opt$endpoint_name,
      PlanName = auto_design_name,
      TreatmentName = opt$treatment_name,
      ControlName = opt$control_name,

      EndpointType = "Time to Event",
      TestingOfSubpopulations = 0,
      WinningCondition = 0,
      PopulationScenarioName = NA,

      TimetoEventModel = "Exponential",
      TimetoEventInputMethod = "Median Survival Time",
      NumberofPieces = 1,
      TimetoEventControl = as.numeric(g$time_to_event_control),
      TimetoEventTreatment = as.numeric(g$time_to_event_treatment),
      TimetoEventHR = time_to_event_hr_input,

      DropoutModel = "Exponential",
      DropoutInputMethod = "Probability of Dropout",
      DropoutByTime = as.numeric(g$dropout_rate_time),
      DropoutControl = as.numeric(g$dropout_rate_control),
      DropoutTreatment = as.numeric(g$dropout_rate_treatment),

      EnrollmentScenarioName = NA,
      EnrollmentInputMethod = "Enrollment Rate",
      EnrollmentDistribution = if (tolower(opt$accrual_model) == "poisson") "Exponential" else "Deterministic",
      AccrualRate = as.numeric(g$accrual_rate),
      NumberOfRegions = 1,

      DesignName = auto_design_name,
      Arms = 2,
      Hypothesis = "Superiority",
      NonInferiorityMargin = 0,

      NumberofEvents = as.integer(g$event_size),
      SampleSize = as.integer(g$sample_size),
      AllocationRatio = as.numeric(g$allocation_ratio),

      SubjectsAreFollowed = "Until End of Study",
      FixedFollowupTime = 0,

      Type1Error = as.numeric(g$alpha),
      TestStatistic = "Logrank",
      TestType = test_type,
      TailType = tail_type,

      EfficacyBoundaryExists = as.integer(eff_stop),
      EfficacyBoundaryFamily = if (eff_stop) "Spending Functions" else NA,
      EfficacySpendingFunction = if (eff_stop) as.character(g$alpha_spending) else NA,
      StopForEfficacy = as.integer(eff_stop),

      FutilityBoundaryExists = as.integer(fut_stop),
      FutilityBoundaryType = if (fut_stop) "Non-Binding" else NA,
      FutilityBoundaryFamily = if (fut_stop) "Spending Functions" else NA,
      FutilitySpendingFunction = if (fut_stop) as.character(g$beta_spending) else NA,
      StopForFutility = as.integer(fut_stop),

      TargetHR = time_to_event_hr_input,

      AdaptionMethod = if (SSR_flag) "Conditional Power SSR" else "None",
      AdaptAtInterimAnalysis = as.integer(SSR_flag),
      MaximumNumberOfEventsIfAdapt = if (is.na(g$event_size_cap)) NA_integer_ else as.integer(g$event_size_cap),
      MaximumSampleSizeIfAdapt = if (is.na(g$sample_size_cap)) NA_integer_ else as.integer(g$sample_size_cap),
      TargetCPForReEstimatingNumberOfEvents = opt$target_CP,
      PromisingZoneMinimumConditionalPower = opt$CP_min,
      PromisingZoneMaximumConditionalPower = opt$CP_max,

      NumberOfSimulationRun = as.integer(opt$n_rep),
      FixedSeed = 1L,
      SeedValue = model_seed,

      AveragePower = summ$power,
      AverageSampleSize = mean(ss, na.rm = TRUE),
      AverageNumberofEvents = mean(ev, na.rm = TRUE),
      AverageDropouts = mean(dr, na.rm = TRUE),
      AverageStudyDuration = mean(sdur, na.rm = TRUE),
      AverageAccrualDuration = mean(ac, na.rm = TRUE),
      FollowUpTime = mean(fu, na.rm = TRUE),

      TypeIIError = as.numeric(opt$beta),

      EfficacyBoundary01 = eff_bound_1,
      FutilityBoundary01 = fut_bound_1,

      SampleSizeMinimumWithinModel = min(ss, na.rm = TRUE),
      SampleSizeMaximumWithinModel = max(ss, na.rm = TRUE),
      SampleSize5thPercentileWithinModel = ss_q[1],
      SampleSize25thPercentileWithinModel = ss_q[2],
      SampleSize50thPercentileWithinModel = ss_q[3],
      SampleSize75thPercentileWithinModel = ss_q[4],
      SampleSize95thPercentileWithinModel = ss_q[5],
      SampleSizeStandardDeviationWithinModel = stats::sd(ss, na.rm = TRUE),

      NumberofEventsMinimumWithinModel = min(ev, na.rm = TRUE),
      NumberofEventsMaximumWithinModel = max(ev, na.rm = TRUE),
      NumberofEvents5thPercentileWithinModel = ev_q[1],
      NumberofEvents25thPercentileWithinModel = ev_q[2],
      NumberofEvents50thPercentileWithinModel = ev_q[3],
      NumberofEvents75thPercentileWithinModel = ev_q[4],
      NumberofEvents95thPercentileWithinModel = ev_q[5],
      NumberofEventsStandardDeviationWithinModel = stats::sd(ev, na.rm = TRUE),

      DropoutsMinimumWithinModel = min(dr, na.rm = TRUE),
      DropoutsMaximumWithinModel = max(dr, na.rm = TRUE),
      Dropouts5thPercentileWithinModel = dr_q[1],
      Dropouts25thPercentileWithinModel = dr_q[2],
      Dropouts50thPercentileWithinModel = dr_q[3],
      Dropouts75thPercentileWithinModel = dr_q[4],
      Dropouts95thPercentileWithinModel = dr_q[5],
      DropoutsStandardDeviationWithinModel = stats::sd(dr, na.rm = TRUE),

      AccrualDurationMinimumWithinModel = min(ac, na.rm = TRUE),
      AccrualDurationMaximumWithinModel = max(ac, na.rm = TRUE),
      AccrualDuration5thPercentileWithinModel = ac_q[1],
      AccrualDuration25thPercentileWithinModel = ac_q[2],
      AccrualDuration50thPercentileWithinModel = ac_q[3],
      AccrualDuration75thPercentileWithinModel = ac_q[4],
      AccrualDuration95thPercentileWithinModel = ac_q[5],
      AccrualDurationStandardDeviationWithinModel = stats::sd(ac, na.rm = TRUE),

      StudyDurationMinimumWithinModel = min(sdur, na.rm = TRUE),
      StudyDurationMaximumWithinModel = max(sdur, na.rm = TRUE),
      StudyDuration5thPercentileWithinModel = sd_q[1],
      StudyDuration25thPercentileWithinModel = sd_q[2],
      StudyDuration50thPercentileWithinModel = sd_q[3],
      StudyDuration75thPercentileWithinModel = sd_q[4],
      StudyDuration95thPercentileWithinModel = sd_q[5],
      StudyDurationStandardDeviationWithinModel = stats::sd(sdur, na.rm = TRUE),

      FollowuptimeMinimumWithinModel = min(fu, na.rm = TRUE),
      FollowuptimeMaximumWithinModel = max(fu, na.rm = TRUE),
      Followuptime5thPercentileWithinModel = fu_q[1],
      Followuptime25thPercentileWithinModel = fu_q[2],
      Followuptime50thPercentileWithinModel = fu_q[3],
      Followuptime75thPercentileWithinModel = fu_q[4],
      Followuptime95thPercentileWithinModel = fu_q[5],
      FollowuptimeStandardDeviationWithinModel = stats::sd(fu, na.rm = TRUE),

      stringsAsFactors = FALSE
    )

    # --------------------------------------------------------------------------
    # SSR-only additions (do not affect GSD output)
    # --------------------------------------------------------------------------
    if (SSR_flag) {
      # Zone powers/probabilities (your existing SSR fields)
      design_row$PowerUnfavorable   <- power_by_zone("unfavorable")
      design_row$PowerPromising     <- power_by_zone("promising")
      design_row$PowerFavorable     <- power_by_zone("favorable")
      design_row$PowerEfficacyZones <- power_by_zone("efficacy")
      design_row$PowerFutilityZones <- power_by_zone("futility")

      design_row$ProbabilityofEnteringUnfavorable   <- p_unfav
      design_row$ProbabilityofEnteringPromising     <- p_prom
      design_row$ProbabilityofEnteringFavorable     <- p_fav
      design_row$ProbabilityofEnteringEfficacyZones <- p_eff
      design_row$ProbabilityofEnteringFutilityZones <- p_fut

      # Some "meta" fields (string conventions like EAST export)
      design_row$PromisingZoneScale <- "Conditional Power - Estimated HR"
      design_row$SSRFunctionInPromisingZone <- "Continuous"
      design_row$ConditionalPowerComputationBasedOn <- "Estimated HR"
      design_row$EnrollmentAfterAdaptation <- "No Change"
      design_row$MultiplierForEnrollmentRateAfterAdaptation <- 0

      # Insufficient info counts (derived from stats)
      n_insuf <- if (!is.null(summ$n_insufficient_info)) summ$n_insufficient_info else sum(raw$insufficient_info, na.rm = TRUE)
      design_row$NumberOfSimulationsWithInsufficientInformation <- as.integer(n_insuf)
      # If you don't explicitly define "after adaptation", keep equal
      design_row$NumberOfSimulationsWithInsufficientInformationAfterAdaptation <- as.integer(n_insuf)

      # Observed HR: define as INPUT HR (assumed). Estimated per-run HR is hr_hat.
      design_row$ObservedHR <- time_to_event_hr_input
      if (!is.null(hr_hat_vec)) {
        design_row$AverageObservedHR <- mean(hr_hat_vec, na.rm = TRUE)
        design_row$MedianObservedHR <- stats::median(hr_hat_vec, na.rm = TRUE)

        design_row$HazardRatioMinimumWithinModel <- hr_s$min
        design_row$HazardRatioMaximumWithinModel <- hr_s$max
        design_row$HazardRatio5thPercentileWithinModel <- hr_s$q05
        design_row$HazardRatio25thPercentileWithinModel <- hr_s$q25
        design_row$HazardRatio50thPercentileWithinModel <- hr_s$q50
        design_row$HazardRatio75thPercentileWithinModel <- hr_s$q75
        design_row$HazardRatio95thPercentileWithinModel <- hr_s$q95
        design_row$HazardRatioStandardDeviationWithinModel <- hr_s$sd
      } else {
        design_row$AverageObservedHR <- NA_real_
        design_row$MedianObservedHR <- NA_real_
        design_row$HazardRatioMinimumWithinModel <- NA_real_
        design_row$HazardRatioMaximumWithinModel <- NA_real_
        design_row$HazardRatio5thPercentileWithinModel <- NA_real_
        design_row$HazardRatio25thPercentileWithinModel <- NA_real_
        design_row$HazardRatio50thPercentileWithinModel <- NA_real_
        design_row$HazardRatio75thPercentileWithinModel <- NA_real_
        design_row$HazardRatio95thPercentileWithinModel <- NA_real_
        design_row$HazardRatioStandardDeviationWithinModel <- NA_real_
      }

      # Zone-wise means (sample size/events/accrual/study durations by zone)
      design_row$SampleSizeUnfavorable   <- zone_mean(raw, "actual_sample_size", "unfavorable")
      design_row$SampleSizePromising     <- zone_mean(raw, "actual_sample_size", "promising")
      design_row$SampleSizeFavorable     <- zone_mean(raw, "actual_sample_size", "favorable")
      design_row$SampleSizeEfficacyZones <- zone_mean(raw, "actual_sample_size", "efficacy")
      design_row$SampleSizeFutilityZones <- zone_mean(raw, "actual_sample_size", "futility")

      design_row$EventsUnfavorable   <- zone_mean(raw, "observed_events", "unfavorable")
      design_row$EventsPromising     <- zone_mean(raw, "observed_events", "promising")
      design_row$EventsFavorable     <- zone_mean(raw, "observed_events", "favorable")
      design_row$EventsEfficacyZones <- zone_mean(raw, "observed_events", "efficacy")
      design_row$EventsFutilityZones <- zone_mean(raw, "observed_events", "futility")

      design_row$AccrualDurationUnfavorable   <- zone_mean(raw, "accrual_stop_time", "unfavorable")
      design_row$AccrualDurationPromising     <- zone_mean(raw, "accrual_stop_time", "promising")
      design_row$AccrualDurationFavorable     <- zone_mean(raw, "accrual_stop_time", "favorable")
      design_row$AccrualDurationEfficacyZones <- zone_mean(raw, "accrual_stop_time", "efficacy")
      design_row$AccrualDurationFutilityZones <- zone_mean(raw, "accrual_stop_time", "futility")

      design_row$StudyDurationUnfavorable   <- zone_mean(raw, "analysis_time", "unfavorable")
      design_row$StudyDurationPromising     <- zone_mean(raw, "analysis_time", "promising")
      design_row$StudyDurationFavorable     <- zone_mean(raw, "analysis_time", "favorable")
      design_row$StudyDurationEfficacyZones <- zone_mean(raw, "analysis_time", "efficacy")
      design_row$StudyDurationFutilityZones <- zone_mean(raw, "analysis_time", "futility")
    } else {
      # GSD: Add stage stopping probabilities (NO zone-related fields)
      design_row$ProbabilityStage1 <- summ$prob_stage1
      design_row$ProbabilityStage2 <- summ$prob_stage2
      design_row$ProbabilityEfficacyStop <- summ$prob_efficacy_stop
      design_row$ProbabilityFutilityStop <- summ$prob_futility_stop

      # Add HR estimates for GSD
      if (!is.null(hr_hat_vec)) {
        design_row$AverageObservedHR <- mean(hr_hat_vec, na.rm = TRUE)
        design_row$MedianObservedHR <- stats::median(hr_hat_vec, na.rm = TRUE)
        design_row$HazardRatioMinimumWithinModel <- hr_s$min
        design_row$HazardRatioMaximumWithinModel <- hr_s$max
        design_row$HazardRatio5thPercentileWithinModel <- hr_s$q05
        design_row$HazardRatio25thPercentileWithinModel <- hr_s$q25
        design_row$HazardRatio50thPercentileWithinModel <- hr_s$q50
        design_row$HazardRatio75thPercentileWithinModel <- hr_s$q75
        design_row$HazardRatio95thPercentileWithinModel <- hr_s$q95
        design_row$HazardRatioStandardDeviationWithinModel <- hr_s$sd
      } else {
        design_row$AverageObservedHR <- NA_real_
        design_row$MedianObservedHR <- NA_real_
        design_row$HazardRatioMinimumWithinModel <- NA_real_
        design_row$HazardRatioMaximumWithinModel <- NA_real_
        design_row$HazardRatio5thPercentileWithinModel <- NA_real_
        design_row$HazardRatio25thPercentileWithinModel <- NA_real_
        design_row$HazardRatio50thPercentileWithinModel <- NA_real_
        design_row$HazardRatio75thPercentileWithinModel <- NA_real_
        design_row$HazardRatio95thPercentileWithinModel <- NA_real_
        design_row$HazardRatioStandardDeviationWithinModel <- NA_real_
      }
    }
  }

  # Collect design row (no longer writing per-model files)
  design_rows[[i]] <- design_row
}

t1_all <- Sys.time()
elapsed_all <- as.numeric(difftime(t1_all, t0_all, units = "secs"))

design_report_all <- do.call(rbind, design_rows)
write.csv(design_report_all, output_file, row.names = FALSE)

cat("\n============================================================\n")
cat("TTE MC finished (GRID MODE)\n")
cat("============================================================\n")
cat(sprintf("Total models: %d\n", nrow(grid)))
cat(sprintf("Total elapsed: %s\n", fmt_seconds(elapsed_all)))
cat("Output file:\n")
cat(" - design_report_wide.csv (ALL MODELS; ModelID is the first column)\n")
cat("============================================================\n")