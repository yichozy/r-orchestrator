#!/usr/bin/env Rscript
library(survival)
library(rpact)
#' Simulate an event-driven time-to-event trial
#'
#' @param event_size Planned number of observed events required for final analysis.
#' @param sample_size Planned maximum number of patients to enroll.
#' @param time_to_event_control Assumed control-arm median time to event under an exponential model.
#' @param time_to_event_treatment Assumed treatment-arm median time to event under an exponential model.
#' @param dropout_rate_control Assumed cumulative dropout probability in control arm by dropout_rate_time.
#' @param dropout_rate_treatment Assumed cumulative dropout probability in treatment arm by dropout_rate_time.
#' @param dropout_rate_time Time horizon used to define dropout_rate_control and dropout_rate_treatment.
#' @param accrual_rate Planned accrual rate in patients per month.
#' @param alpha Significance level.
#' @param sided "one-sided" or "two-sided".
#' @param allocation_ratio Treatment:control allocation ratio. Default 1 means 1:1.
#' @param accrual_model "poisson" or "fixed_spacing".
#' @param randomization_method "blocked" or "bernoulli".
#' @param block_size Block size for blocked randomization. Ignored for bernoulli.
#' @param seed Optional random seed.
#' @param return_patient_data Logical; if TRUE return final analysis dataset.
#' @param beta 1 - target power.
#'
#' @details
#' Recruitment is driven by accrual_rate up to a maximum of sample_size patients.
#' If event_size observed events is reached before sample_size is accrued,
#' recruitment stops and final analysis is performed immediately.
#' If sample_size is reached first, recruitment stops and follow-up continues until either:
#'   1) event_size observed events is reached, or
#'   2) all enrolled patients have had an event or dropout.
#'
#'
#'
#' Interim analysis related:
#' @param interim_ratio The ratio of event inforamtion to conduct an interim analysis. For example, 0.5 means an interim analysis at 50% of the planned events.
#' @param efficacy_stop A logical indicating whether to stop for efficacy at the interim analysis if the test statistic crosses the efficacy boundary.
#' @param futility_stop A logical indicating whether to stop for futility at the interim analysis if the test statistic crosses the futility boundary. Can be true only if efficacy_stop is TRUE.
#' @param alpha_spending The type of alpha spending function to use for the interim analysis. Choose one of the following options: O’Brien & Fleming type alpha spending ("asOF"), Pocock type alpha spending ("asP"), Kim & DeMets alpha spending ("asKD"), Hwang, Shi & DeCani alpha spending ("asHSD"), default to be "asOF" is efficacy_stop == TRUE.
#' @param beta_spending The type of beta spending function to use for the interim analysis. Choose one of the following options: O’Brien & Fleming type beta spending ("bsOF"), Pocock type beta spending ("bsP"), Kim & DeMets beta spending ("bsKD"), Hwang, Shi & DeCani beta spending ("bsHSD"), default to be "bsOF" is futility_stop == TRUE.
#'
#'



#'The final hypothesis test is a log-rank test.
#'
#' @return A list with:
#'   - analysis_data: final analysis dataset (optional)
#'   - test_result: U, V, Z, chisq, p_value, critical_value, reject
#'   - timing: key stopping times used internally
#
# DEFINED FUNCTIONS
#
#
#
#
# =========================================================
# Required package
# =========================================================
# install.packages("survival")  # if needed

# =========================================================
# Helper 1: convert dropout probability by time t0
# to exponential dropout hazard
# =========================================================
rate_from_target <- function(p_at_t0, t0) {
  if (!is.numeric(p_at_t0) || length(p_at_t0) != 1 || is.na(p_at_t0)) {
    stop("p_at_t0 must be a single non-missing numeric value.")
  }
  if (!is.numeric(t0) || length(t0) != 1 || is.na(t0)) {
    stop("t0 must be a single non-missing numeric value.")
  }
  if (p_at_t0 < 0 || p_at_t0 >= 1) {
    stop("p_at_t0 must be in [0, 1).")
  }
  if (t0 <= 0) {
    stop("t0 must be > 0.")
  }

  -log(1 - p_at_t0) / t0
}

# =========================================================
# Helper 2: robust 2-arm randomization
# treatment = 1, control = 0
# allocation_ratio means trt:ctrl = allocation_ratio:1
# =========================================================
randomize_two_arm <- function(sample_size,
                              allocation_ratio = 1,
                              method = c("blocked", "bernoulli"),
                              block_size = NULL) {
  method <- match.arg(method)

  if (!is.numeric(sample_size) || length(sample_size) != 1 || is.na(sample_size) || sample_size <= 0) {
    stop("sample_size must be a single positive integer.")
  }
  sample_size <- as.integer(sample_size)

  if (!is.numeric(allocation_ratio) || length(allocation_ratio) != 1 || is.na(allocation_ratio) || allocation_ratio <= 0) {
    stop("allocation_ratio must be a single positive numeric value.")
  }

  p_trt <- allocation_ratio / (allocation_ratio + 1)

  if (method == "bernoulli") {
    return(stats::rbinom(sample_size, size = 1, prob = p_trt))
  }

  # blocked randomization
  if (is.null(block_size)) {
    # default block size
    block_size <- 2 * (allocation_ratio + 1)
  }

  if (!is.numeric(block_size) || length(block_size) != 1 || is.na(block_size) || block_size <= 0) {
    stop("block_size must be a single positive integer.")
  }
  block_size <- as.integer(block_size)

  if (block_size %% (allocation_ratio + 1) != 0) {
    stop("For blocked randomization, block_size must be divisible by allocation_ratio + 1.")
  }

  n_trt_block <- as.integer(block_size * allocation_ratio / (allocation_ratio + 1))
  n_ctrl_block <- block_size - n_trt_block

  block_template <- c(rep(1L, n_trt_block), rep(0L, n_ctrl_block))

  n_full_blocks <- sample_size %/% block_size
  n_rem <- sample_size %% block_size

  out <- integer(0)

  if (n_full_blocks > 0) {
    full_blocks <- replicate(n_full_blocks, sample(block_template, block_size, replace = FALSE))
    out <- c(out, as.integer(full_blocks))
  }

  if (n_rem > 0) {
    # robust leftover handling: use Bernoulli for remainder
    out <- c(out, stats::rbinom(n_rem, size = 1, prob = p_trt))
  }

  out[seq_len(sample_size)]
}

# =========================================================
# Helper 3: accrual times from accrual rate
# =========================================================
generate_accrual_times <- function(sample_size,
                                   accrual_rate,
                                   accrual_model = c("poisson", "fixed_spacing")) {
  accrual_model <- match.arg(accrual_model)

  if (!is.numeric(sample_size) || length(sample_size) != 1 || is.na(sample_size) || sample_size <= 0) {
    stop("sample_size must be a single positive integer.")
  }
  sample_size <- as.integer(sample_size)

  if (!is.numeric(accrual_rate) || length(accrual_rate) != 1 || is.na(accrual_rate) || accrual_rate <= 0) {
    stop("accrual_rate must be a single positive numeric value.")
  }

  if (accrual_model == "poisson") {
    inter_arrival_times <- stats::rexp(sample_size, rate = accrual_rate)
  } else {
    inter_arrival_times <- rep(1 / accrual_rate, sample_size)
  }

  cumsum(inter_arrival_times)
}

# =========================================================
# Helper 4: log-rank statistic + critical value
# Assumption:
#   - treatment coded as 1
#   - control coded as 0
#   - treatment benefit => fewer events in treatment => negative Z
# =========================================================
compute_logrank_statistic <- function(dat) {
  if (!requireNamespace("survival", quietly = TRUE)) {
    stop("Package 'survival' is required.")
  }

  required_cols <- c("time", "status", "treat")
  if (!all(required_cols %in% names(dat))) {
    stop("dat must contain columns: time, status, treat.")
  }

  if (nrow(dat) == 0) {
    stop("dat has 0 rows.")
  }

  if (length(unique(dat$treat)) < 2) {
    return(list(
      U = NA_real_,
      V = NA_real_,
      Z = NA_real_,
      chisq = NA_real_
    ))
  }

  if (sum(dat$status) == 0) {
    return(list(
      U = 0,
      V = NA_real_,
      Z = 0,
      chisq = 0
    ))
  }

  fit <- tryCatch(
    survival::survdiff(survival::Surv(time, status) ~ treat, data = dat, rho = 0),
    error = function(e) NULL
  )

  if (is.null(fit)) {
    return(list(
      U = NA_real_,
      V = NA_real_,
      Z = NA_real_,
      chisq = NA_real_
    ))
  }

  chisq <- unname(fit$chisq)

  # treat = 1 is assumed to be the second group if coded as 0/1
  O1 <- fit$obs[2]
  E1 <- fit$exp[2]
  U <- O1 - E1

  V <- if (!is.na(chisq) && chisq > 0) U^2 / chisq else NA_real_
  Z <- if (!is.na(V) && V > 0) U / sqrt(V) else 0

  list(
    U = U,
    V = V,
    Z = Z,
    chisq = chisq
  )
}

get_critical_value <- function(alpha, sided = c("one-sided", "two-sided")) {
  sided <- match.arg(sided)

  if (!is.numeric(alpha) || length(alpha) != 1 || is.na(alpha) || alpha <= 0 || alpha >= 1) {
    stop("alpha must be a single numeric value in (0, 1).")
  }

  if (sided == "one-sided") {
    stats::qnorm(1 - alpha)
  } else {
    stats::qnorm(1 - alpha / 2)
  }
}



# =========================================================
# Helper 5: find critical bound at interim analysis based on alpha spending function and beta spending function.
# Assumption:
#   - With SSR, we only allow single interim analysis at a pre-specified information fraction (interim_ratio).
# =========================================================

get_interim_critical_value <- function(alpha,
                                       beta,
                                       sided = c("one-sided", "two-sided"),
                                       interim_ratio,
                                       alpha_spending = "asOF",
                                       beta_spending = "bsOF",
                                       futility_stop = TRUE) {

  if (!is.numeric(alpha) || length(alpha) != 1 || is.na(alpha) || alpha <= 0 || alpha >= 1) {
    stop("alpha must be a single numeric value in (0, 1).")
  }

  if (!is.numeric(beta) || length(beta) != 1 || is.na(beta) || beta <= 0 || beta >= 1) {
    stop("beta must be a single numeric value in (0, 1).")
  }

  if (!is.numeric(interim_ratio) || length(interim_ratio) != 1 || is.na(interim_ratio) || interim_ratio <= 0 || interim_ratio >= 1) {
    stop("interim_ratio must be a single numeric value in (0, 1).")
  }
    
    sided_ind <- ifelse(sided == "one-sided", 1, 2)

  if (sided == "two-sided" || !futility_stop) {
    design <- getDesignGroupSequential(
      alpha = alpha, beta = beta, sided = sided_ind,
      typeOfDesign = alpha_spending,
      typeBetaSpending = "none",
      kMax = 2, informationRates = c(interim_ratio, 1)
    )
    summary_design <- summary(design)
    efficacy_bound <- as.numeric(summary_design$summaryItems[[5]]$values)
    futility_bound <- rep(NA_real_, 2)
  } else {
    design <- getDesignGroupSequential(
      alpha = alpha, beta = beta, sided = sided_ind,
      typeOfDesign = alpha_spending,
      typeBetaSpending = beta_spending,
      kMax = 2, informationRates = c(interim_ratio, 1)
    )
    summary_design <- summary(design)
    efficacy_bound <- as.numeric(summary_design$summaryItems[[6]]$values)
    futility_bound <- as.numeric(summary_design$summaryItems[[7]]$values)
  }

    list(
      efficacy_bound = efficacy_bound,
      futility_bound = futility_bound
    )
}



# =========================================================
# Helper 6: Construct dataset at cutoff time and summarize key stats
# =========================================================

build_dataset_at_cutoff <- function(cutoff_time,
                                    arrival_times,
                                    treat,
                                    event_calendar,
                                    dropout_calendar,
                                    tau_N) {
  if (!is.finite(cutoff_time)) {
    return(NULL)
  }

  # If cutoff is before full accrual, only already-enrolled patients are included.
  # If cutoff is after full accrual, all planned patients are included.
  enrolled_idx <- which(arrival_times <= min(cutoff_time, tau_N))

  if (length(enrolled_idx) == 0) {
    return(NULL)
  }

  arr <- arrival_times[enrolled_idx]
  trt <- treat[enrolled_idx]
  evt <- event_calendar[enrolled_idx]
  drp <- dropout_calendar[enrolled_idx]

  observed_calendar <- pmin(evt, drp, cutoff_time)
  status <- as.integer(evt <= pmin(drp, cutoff_time))
  time <- observed_calendar - arr

  dropout_status <- as.integer(drp < evt & drp <= cutoff_time)
  n_dropout <- sum(dropout_status)

  dat <- data.frame(
    id = seq_along(enrolled_idx),
    treat = trt,
    entry_time = arr,
    time = time,
    status = status,
    dropout_status = dropout_status
  )

  list(
    data = dat,
    enrolled_idx = enrolled_idx,
    n_enrolled = nrow(dat),
    n_event = sum(status),
    n_dropout = n_dropout,
    cutoff_time = cutoff_time,
    last_patient_followup = cutoff_time - max(arr)
  )
}



# =========================================================
# Main function
# =========================================================


simulate_event_driven_tte <- function(
    event_size,
    sample_size,
    time_to_event_control,
    time_to_event_treatment,
    dropout_rate_control,
    dropout_rate_treatment,
    dropout_rate_time,
    accrual_rate,
    alpha = 0.025,
    sided = c("one-sided", "two-sided"),
    allocation_ratio = 1,
    accrual_model = c("poisson", "fixed_spacing"),
    randomization_method = c("blocked", "bernoulli"),
    block_size = NULL,
    seed = NULL,
    return_patient_data = TRUE,
    interim_ratio = NULL,
    efficacy_stop = TRUE,
    futility_stop = TRUE,
    alpha_spending = "asOF",
    beta_spending = "bsOF",
    beta = 0.2
) {
  sided <- match.arg(sided)
  accrual_model <- match.arg(accrual_model)
  randomization_method <- match.arg(randomization_method)

  if (!is.null(seed)) {
    set.seed(seed)
  }

  # -------------------------
  # Input checks
  # -------------------------
  if (!is.numeric(event_size) || length(event_size) != 1 || is.na(event_size) || event_size <= 0) {
    stop("event_size must be a single positive integer.")
  }
  event_size <- as.integer(event_size)

  if (!is.numeric(sample_size) || length(sample_size) != 1 || is.na(sample_size) || sample_size <= 0) {
    stop("sample_size must be a single positive integer.")
  }
  sample_size <- as.integer(sample_size)

  if (sample_size <= event_size) {
    stop("sample_size must be greater than event_size.")
  }

  if (!is.numeric(time_to_event_control) || length(time_to_event_control) != 1 ||
      is.na(time_to_event_control) || time_to_event_control <= 0) {
    stop("time_to_event_control must be a single positive numeric value.")
  }

  if (!is.numeric(time_to_event_treatment) || length(time_to_event_treatment) != 1 ||
      is.na(time_to_event_treatment) || time_to_event_treatment <= 0) {
    stop("time_to_event_treatment must be a single positive numeric value.")
  }

  if (!is.numeric(alpha) || length(alpha) != 1 || is.na(alpha) || alpha <= 0 || alpha >= 1) {
    stop("alpha must be a single numeric value in (0, 1).")
  }

  # -------------------------
  # Derived hazards
  # -------------------------
  lambda_c <- log(2) / time_to_event_control
  lambda_t <- log(2) / time_to_event_treatment

  lambda_d_c <- rate_from_target(dropout_rate_control, dropout_rate_time)
  lambda_d_t <- rate_from_target(dropout_rate_treatment, dropout_rate_time)


  # -------------------------
  # Interim timing and boundaries
  # -------------------------
interim_event <- NA_integer_
interim_bounds <- NULL

if (!is.null(interim_ratio)) {
  if (!is.numeric(interim_ratio) || length(interim_ratio) != 1 ||
      is.na(interim_ratio) || interim_ratio <= 0 || interim_ratio >= 1) {
    stop("interim_ratio must be a single numeric value in (0, 1).")
  }

  interim_event <- ceiling(event_size * interim_ratio)

  if (interim_event < 1) {
    interim_event <- 1L
  }
  if (interim_event >= event_size) {
    interim_event <- event_size - 1L
  }

  if (sided == "two-sided" && futility_stop) {
    warning(
      "futility_stop is not supported for two-sided designs via rpact beta spending. ",
      "futility_stop will be set to FALSE for this design."
    )
    futility_stop <- FALSE
  }

  interim_bounds <- get_interim_critical_value(
    alpha = alpha,
    beta = beta,
    sided = sided,
    interim_ratio = interim_ratio,
    alpha_spending = alpha_spending,
    beta_spending = beta_spending,
    futility_stop = futility_stop
  )
}
  # -------------------------
  # Simulate candidate patients up to sample_size
  # -------------------------
  treat <- randomize_two_arm(
    sample_size = sample_size,
    allocation_ratio = allocation_ratio,
    method = randomization_method,
    block_size = block_size
  )

  arrival_times <- generate_accrual_times(
    sample_size = sample_size,
    accrual_rate = accrual_rate,
    accrual_model = accrual_model
  )

  event_times <- numeric(sample_size)
  event_times[treat == 0] <- stats::rexp(sum(treat == 0), rate = lambda_c)
  event_times[treat == 1] <- stats::rexp(sum(treat == 1), rate = lambda_t)

  dropout_times <- numeric(sample_size)
  dropout_times[treat == 0] <- if (lambda_d_c > 0) stats::rexp(sum(treat == 0), rate = lambda_d_c) else Inf
  dropout_times[treat == 1] <- if (lambda_d_t > 0) stats::rexp(sum(treat == 1), rate = lambda_d_t) else Inf

  event_calendar <- arrival_times + event_times
  dropout_calendar <- arrival_times + dropout_times

  # -------------------------
  # Key stopping times
  # -------------------------
  tau_N <- arrival_times[sample_size]

  observable_event_calendar_all <- sort(event_calendar[event_calendar <= dropout_calendar])



  tau_D_all <- if (length(observable_event_calendar_all) >= event_size) {
    observable_event_calendar_all[event_size]
  } else {
    Inf
  }

  # -------------------------
  # Apply your stopping rule
  # -------------------------
  if (is.finite(tau_D_all) && tau_D_all <= tau_N) {
    # Event target reached before sample cap
    accrual_stop_time <- tau_D_all
    final_analysis_time <- tau_D_all
    enrolled_idx <- which(arrival_times <= final_analysis_time)
  } else {
    # Sample cap reached first
    accrual_stop_time <- tau_N
    enrolled_idx <- seq_len(sample_size)

    observable_event_calendar_enrolled <- sort(
      event_calendar[enrolled_idx][event_calendar[enrolled_idx] <= dropout_calendar[enrolled_idx]]
    )

    tau_all_resolved <- max(pmin(event_calendar[enrolled_idx], dropout_calendar[enrolled_idx]))

    if (length(observable_event_calendar_enrolled) >= event_size) {
      final_analysis_time <- observable_event_calendar_enrolled[event_size]
    } else {
      final_analysis_time <- tau_all_resolved
    }
  }

  # -------------------------
  # Construct final analysis dataset
  # -------------------------
  arr <- arrival_times[enrolled_idx]
  trt <- treat[enrolled_idx]
  evt <- event_calendar[enrolled_idx]
  drp <- dropout_calendar[enrolled_idx]

  observed_calendar <- pmin(evt, drp, final_analysis_time)
  status <- as.integer(evt <= pmin(drp, final_analysis_time))
  time <- observed_calendar - arr
  dropout_status <- as.integer(drp < evt & drp <= final_analysis_time)
  n_dropout <- sum(dropout_status)

  analysis_data <- data.frame(
    id = seq_along(enrolled_idx),
    treat = trt,
    entry_time = arr,
    time = time,
    status = status,
    dropout_status = dropout_status
  )


interim_res <- NULL
interim_data <- NULL
interim_stat <- NULL

interim_n_enrolled <- NA_integer_
interim_n_event <- NA_integer_
interim_n_dropout <- NA_integer_
interim_time <- NA_real_
interim_last_patient_followup <- NA_real_

if (!is.na(interim_event)) {
  tau_interim_all <- if (length(observable_event_calendar_all) >= interim_event) {
    observable_event_calendar_all[interim_event]
  } else {
    Inf
  }

  interim_res <- build_dataset_at_cutoff(
    cutoff_time = tau_interim_all,
    arrival_times = arrival_times,
    treat = treat,
    event_calendar = event_calendar,
    dropout_calendar = dropout_calendar,
    tau_N = tau_N
  )

  interim_data <- if (!is.null(interim_res)) interim_res$data else NULL
  interim_n_enrolled <- if (!is.null(interim_res)) interim_res$n_enrolled else NA_integer_
  interim_n_event <- if (!is.null(interim_res)) interim_res$n_event else NA_integer_
  interim_n_dropout <- if (!is.null(interim_res)) interim_res$n_dropout else NA_integer_
  interim_time <- if (!is.null(interim_res)) interim_res$cutoff_time else NA_real_
  interim_last_patient_followup <- if (!is.null(interim_res)) interim_res$last_patient_followup else NA_real_

  interim_stat <- if (!is.null(interim_data)) {
    compute_logrank_statistic(interim_data)
  } else {
    NULL
  }
}


# Interim test
reject <- FALSE
zone_label <- "continue"
early_stop <- FALSE

if (!is.null(interim_stat) && !is.null(interim_bounds)) {
  # Check efficacy first
  if (efficacy_stop) {
    if (!is.na(interim_stat$Z) && !is.na(interim_bounds$efficacy_bound[1]) &&
        interim_stat$Z <= -interim_bounds$efficacy_bound[1]) {
      early_stop <- TRUE
      zone_label <- "efficacy"
      reject <- TRUE
    }
  }

  # If not efficacy, check futility
  if (!early_stop && futility_stop) {
    if (!is.na(interim_stat$Z) && !is.na(interim_bounds$futility_bound[1]) &&
        interim_stat$Z >= -interim_bounds$futility_bound[1]) {
      early_stop <- TRUE
      zone_label <- "futility"
      reject <- FALSE
    }
  }
}


  # -------------------------
  # Final log-rank test
  # -------------------------
test_stat <- compute_logrank_statistic(analysis_data)

# Default critical value: no interim efficacy spending
critical_value <- get_critical_value(alpha = alpha, sided = sided)

if (!early_stop) {
  # If interim efficacy stopping is enabled, adjust final efficacy boundary
  if (!is.null(interim_bounds) && efficacy_stop && !is.na(interim_bounds$efficacy_bound[2])) {
    critical_value <- interim_bounds$efficacy_bound[2]
  }

  if (sided == "one-sided") {
    reject <- !is.na(test_stat$Z) && !is.na(critical_value) && (test_stat$Z <= -critical_value)
  } else {
    reject <- !is.na(test_stat$Z) && !is.na(critical_value) && (abs(test_stat$Z) >= critical_value)
  }
}

if (!early_stop && !efficacy_stop) {
    # If efficacy stop is not enabled, we use the original critical value without adjustment.
if (sided == "one-sided") {
  # treatment benefit assumed to correspond to negative Z
  reject <- !is.na(test_stat$Z) && !is.na(critical_value) && (test_stat$Z <= -critical_value)
} else {
  reject <- !is.na(test_stat$Z) && !is.na(critical_value) && (abs(test_stat$Z) >= critical_value)
}
}


  # -------------------------
  # Minimal return
  # -------------------------

if (zone_label %in% c("efficacy", "futility")) {
  output_test_stat <- interim_stat
  output_time <- interim_time
  output_sample_size <- interim_n_enrolled
  output_events <- interim_n_event
  output_n_dropout <- interim_n_dropout
  output_last_patient_followup <- interim_last_patient_followup
  output_data <- interim_data

  if (zone_label == "efficacy") {
    output_critical_value <- interim_bounds$efficacy_bound[1]
  } else {
    output_critical_value <- interim_bounds$futility_bound[1]
  }
} else {
  output_test_stat <- test_stat
  output_time <- final_analysis_time
  output_sample_size <- nrow(analysis_data)
  output_events <- sum(analysis_data$status)
  output_n_dropout <- n_dropout
  output_last_patient_followup <- final_analysis_time - max(analysis_data$entry_time)
  output_data <- analysis_data
  output_critical_value <- critical_value
}

# Calculate HR estimate from logrank statistics
U <- if (!is.null(output_test_stat$U)) output_test_stat$U else NA_real_
V <- if (!is.null(output_test_stat$V)) output_test_stat$V else NA_real_
beta_hat <- if (is.finite(U) && is.finite(V) && V > 0) U / V else NA_real_
hr_hat <- if (is.finite(beta_hat)) exp(beta_hat) else NA_real_


out <- list(
  zone_label = zone_label,
  early_stop = early_stop,
  test_stat = output_test_stat,
  critical_value = output_critical_value,
  reject = reject,
  beta_hat = beta_hat,
  hr_hat = hr_hat,
  interim_bounds = interim_bounds,
  timing = list(
    accrual_stop_time = accrual_stop_time,
    analysis_time = output_time,
    actual_sample_size = output_sample_size,
    observed_events = output_events,
    last_patient_followup = output_last_patient_followup,
    n_dropout = output_n_dropout
  ),
  zone = zone_label
)

if (return_patient_data) {
  out$analysis_data <- output_data
}

  out
}



